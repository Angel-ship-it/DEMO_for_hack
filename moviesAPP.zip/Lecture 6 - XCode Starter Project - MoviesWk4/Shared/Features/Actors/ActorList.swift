import SwiftUI

struct ActorList: View {
  @State private var actors = Actor.sortedDummyData
  private let movies = Movie.dummyData

  // I pulled this out as a function here to illustrate
  // a different way to accomplish returning a view.
  // It also avoids passing movies around; not a big deal, but still.
  // In real life I would use the ActorRow struct below.
  func actorRow(_ actor: Actor) -> some View {
    let filteredMovies =
      movies
        .filter {
          $0.actors.contains(actor)
        }
        .map { $0.title }
        .joined(separator: ", ")
    return(
      VStack(alignment: .leading) {
        Text(actor.name)
          .font(.headline)
        Text(filteredMovies)
          .font(.caption)
      }
    )
  }
  
  var body: some View {
    List(actors) { thisActor in
      actorRow(thisActor)
    }
    .navigationTitle("Actors")
  }
}

// Passing in Movies here seems annoying. Referencing dummyData separately violates single source of truth.
// We are crying out to access our data in a different way.

struct ActorRow: View {
  let actor: Actor
  let movies: [Movie]

  var filteredMovies: String {
    movies
      .filter {
        $0.actors.contains(actor)
      }
      .map { $0.title }
      .joined(separator: ", ")
  }

  var body: some View {
    VStack(alignment: .leading) {
      Text(actor.name)
        .font(.headline)
      Text(filteredMovies)
        .font(.caption)
    }
  }
}

struct ActorList_Previews: PreviewProvider {
  static var previews: some View {
    NavigationView {
      ActorList()
    }
  }
}
