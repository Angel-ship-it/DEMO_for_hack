import SwiftUI

struct MovieDetail: View {
  @Binding var movie: Movie
  @State private var editSheetIsPresenting: Bool = false

  var body: some View {
    VStack {
      Text(movie.title)
        .font(.largeTitle)
      Toggle(isOn: $movie.viewed, label: { Text("I Viewed this movie")} )
        .fixedSize()
      Button { movie.viewed = (self.movie.viewed ? false : true) } label: { Text(movie.viewed ? "Change to Unviewed" : "Change to Viewed") }

      Text(self.movie.viewed ? "I SAW IT" : "DID NOT SEE")
      VStack(alignment: .leading) {
        Text("Starring: ")
          .modifier(InfoSectionHeader())
        ForEach(movie.actors.sorted { $0.sortableName < $1.sortableName }) { movieActor in
          Text(movieActor.name)
        }
        Text("Directed By: ")
          .font(.headline)
          .padding(6)
          .background(RoundedRectangle(cornerRadius: 30).foregroundColor(Color.yellow))
      }
      .padding(.top, 100)
    }
    .toolbar {
      ToolbarItem(placement: .primaryAction) { Button("Edit") { editSheetIsPresenting = true } }
    }
    .sheet(isPresented: $editSheetIsPresenting) { Text("Edit form to come!") }
  }
}

struct MovieDetail_Previews: PreviewProvider {
  static var previews: some View {
    StatefulPreviewWrapper(Movie.dummyData[0]) {
      MovieDetail(movie: $0)
    }
  }
}

// I would move to some Utilties group in it's own file.
// It's here to be near where it is being called above, to allow us
// to use a binding in our preview.
// It is constructing a binding on the fly.
// At some point, we will understand this :-). For now it can be magic.
struct StatefulPreviewWrapper<Value, Content: View>: View {
  @State var value: Value
  var content: (Binding<Value>) -> Content

  var body: some View {
    content($value)
  }

  init(_ value: Value, content: @escaping (Binding<Value>) -> Content) {
    self._value = State(wrappedValue: value)
    self.content = content
  }
}
