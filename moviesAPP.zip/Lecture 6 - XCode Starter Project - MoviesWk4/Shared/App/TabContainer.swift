import SwiftUI

struct TabContainer: View {
  @State private var selectedTab: Tab = .movies
  
  enum Tab {
    case movies
    case actors
  }
  
  var body: some View {
    Group {
      TabView(selection: $selectedTab) {
        NavigationView {
          MovieList()
        }
        .tabItem {
          Label("Movies", systemImage: "film")
            .accessibility(label: Text("Movies"))
        }
        .tag(Tab.movies)
        
        NavigationView {
          ActorList()
        }
        .tabItem {
          Label("Actors", systemImage: "person")
            .accessibility(label: Text("Actors"))
        }
        .tag(Tab.actors)
      }
    }
  }
}

struct TabContainer_Previews: PreviewProvider {
  static var previews: some View {
    TabContainer()
  }
}
