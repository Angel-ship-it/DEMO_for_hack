import Foundation

struct Actor: Identifiable, Equatable {
  let id: UUID = UUID()
  var name: String

  var sortableName: String {
    name
      .split(separator: " ")
      .map(String.init)
      .reversed()
      .joined(separator: ", ")
  }
}

extension Actor {
  static let sortedDummyData = dummyData.sorted { $0.sortableName < $1.sortableName }
  static let dummyData = [awkwafina, bacon, chalamet, cumberbatch, elba, holland, king, ronan, zendaya]

  static let awkwafina = Actor(name: "Awkwafina")
  static let bacon = Actor(name: "Kevin Bacon")
  static let chalamet = Actor(name: "Timothée Chalamet")
  static let cumberbatch = Actor(name: "Benedict Cumberbatch")
  static let elba = Actor(name: "Idris Elba")
  static let holland = Actor(name: "Tom Holland")
  static let king = Actor(name: "Regina King")
  static let ronan = Actor(name: "Saoirse Ronan")
  static let zendaya = Actor(name: "Zendaya")
}
